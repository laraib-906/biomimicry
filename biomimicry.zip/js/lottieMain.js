var animation = bodymovin.loadAnimation({
    container: document.getElementById('backgroud-ani'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: "../media/lottie/Background.json",
    innerHeight:100
})

var animation = bodymovin.loadAnimation({
    container: document.getElementById('ball-ani'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: "../media/lottie/Bouncing_Ball.json",
    innerHeight:100
})
